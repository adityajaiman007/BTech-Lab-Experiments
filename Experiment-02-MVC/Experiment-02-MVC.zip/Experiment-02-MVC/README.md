# Experiment 2: MVC (Model–View–Controller) in Java

## Aim
To demonstrate the Model–View–Controller (MVC) design pattern using a small Java console program.

## Concept
- **Model** stores the data and business logic.
- **View** displays information to the user.
- **Controller** accepts user actions and coordinates the Model and View.

## Project files
- `src/Student.java` — Model
- `src/StudentView.java` — View
- `src/StudentController.java` — Controller and program entry point

## Requirements
Java JDK 8 or newer.

## Compile and run
Open a terminal in this folder and run:

```bash
javac -d out src/*.java
java -cp out StudentController
```

## Expected sample output
```text
Enter student name: Aditi
Enter roll number: 12

--- Student Details ---
Name: Aditi
Roll number: 12
```

This is a small educational example, not a production application.
